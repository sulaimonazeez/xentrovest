import { createContext, useState, useEffect, useCallback } from "react";
import { setLogoutHandler } from "./AuthEvents";
import { setAuthToken, clearAuthToken, getAuthToken } from "../api/utility";
import axiosInstance from "../api/utility";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    // Restore user from localStorage immediately — prevents flash on refresh
    try {
      const stored = localStorage.getItem("user");
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(true);

  // ── On mount: validate stored token against backend ──
  useEffect(() => {
    const restore = async () => {
      const token = getAuthToken();
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const res = await axiosInstance.get("/api/check");
        if (res.data?.user) {
          setUser(res.data.user);
          localStorage.setItem("user", JSON.stringify(res.data.user));
        } else {
          _clearSession();
        }
      } catch {
        // Token invalid or expired
        _clearSession();
      } finally {
        setLoading(false);
      }
    };
    restore();
  }, []);

  // ── Internal: clear all session data ──
  const _clearSession = () => {
    clearAuthToken();
    localStorage.removeItem("user");
    setUser(null);
  };

  // ── Login ──
  const login = useCallback((userData, token) => {
    setAuthToken(token);
    setUser(userData);
    localStorage.setItem("user", JSON.stringify(userData));
  }, []);

  // ── Logout ──
  const logout = useCallback(async () => {
    try {
      await axiosInstance.post("/api/logout");
    } catch {}
    _clearSession();
    window.location.href = "/login";
  }, []);

  // Register logout globally for axios interceptor
  useEffect(() => {
    setLogoutHandler(logout);
  }, [logout]);

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      isAuthenticated: !!user,
      login,
      logout,
    }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};